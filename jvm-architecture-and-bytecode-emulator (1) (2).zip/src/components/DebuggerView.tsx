import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  SkipForward,
  RotateCcw,
  Circle,
  CheckCircle,
  AlertCircle,
  Layers,
  HardDrive,
  Database,
  ArrowRight,
  Terminal,
  Search,
  Sparkles,
  Code,
  Trophy,
  Cpu,
  Edit3,
  Save,
  FileCode,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { ExecutionSnapshot, InstructionIR, JvmValue, StepTraceEntry } from '../jvm/types';
import { SampleProgramDef, SAMPLE_PROGRAMS } from '../jvm/samples';
import { JvmArchitectureArt } from './JvmArchitectureArt';
import { JvmHeapD3Visualizer } from './JvmHeapD3Visualizer';
import { JavaCompiler } from '../jvm/javaCompiler';
import { BytecodeParser } from '../jvm/parser';

interface DebuggerViewProps {
  snapshot: ExecutionSnapshot;
  instructions: InstructionIR[];
  traces: StepTraceEntry[];
  selectedProgram: SampleProgramDef;
  programArgs: number[];
  onProgramChange: (prog: SampleProgramDef) => void;
  onArgsChange: (args: number[]) => void;
  onStep: () => void;
  onRun: () => void;
  onPause: () => void;
  onReset: () => void;
  onToggleBreakpoint: (pc: number) => void;
  speedMs: number;
  onSpeedChange: (ms: number) => void;
  onEditInAssembler?: () => void;
  onOpenLeetCode?: () => void;
}

export const DebuggerView: React.FC<DebuggerViewProps> = ({
  snapshot,
  instructions,
  traces,
  selectedProgram,
  programArgs,
  onProgramChange,
  onArgsChange,
  onStep,
  onRun,
  onPause,
  onReset,
  onToggleBreakpoint,
  speedMs,
  onSpeedChange,
  onEditInAssembler,
  onOpenLeetCode,
}) => {
  const [traceSearch, setTraceSearch] = useState('');
  const [showArchitectureArt, setShowArchitectureArt] = useState(false);
  const bytecodeContainerRef = useRef<HTMLDivElement>(null);
  const traceTableRef = useRef<HTMLDivElement>(null);
  const [heapDisplayMode, setHeapDisplayMode] = useState<'d3' | 'raw'>('d3');
  const [showD3Modal, setShowD3Modal] = useState<boolean>(false);

  // Interactive Java Source Editor State
  const [isEditingJava, setIsEditingJava] = useState(false);
  const [editedJavaSource, setEditedJavaSource] = useState(selectedProgram.javaSourceSnippet);
  const [javaCompileError, setJavaCompileError] = useState<string | null>(null);
  const [javaCompileSuccess, setJavaCompileSuccess] = useState(false);

  useEffect(() => {
    setEditedJavaSource(selectedProgram.javaSourceSnippet);
    setJavaCompileError(null);
    setJavaCompileSuccess(false);
  }, [selectedProgram]);

  const handleApplyJavaEdit = () => {
    try {
      setJavaCompileError(null);
      setJavaCompileSuccess(false);

      const res = JavaCompiler.compile(editedJavaSource);
      if (!res.success) {
        throw new Error(res.errorMessage || 'Java compilation failed');
      }

      // Verify bytecode assembly
      BytecodeParser.assemble(res.assemblySource);

      const updatedProgram: SampleProgramDef = {
        ...selectedProgram,
        javaSourceSnippet: editedJavaSource,
        assemblySource: res.assemblySource,
      };

      onProgramChange(updatedProgram);
      setJavaCompileSuccess(true);
      setTimeout(() => setJavaCompileSuccess(false), 3000);
    } catch (e: any) {
      setJavaCompileError(e.message || String(e));
    }
  };

  // Auto-scroll bytecode list to active PC
  useEffect(() => {
    if (bytecodeContainerRef.current) {
      const activeElem = bytecodeContainerRef.current.querySelector('[data-active-pc="true"]');
      if (activeElem) {
        activeElem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }
  }, [snapshot.pc]);

  // Auto-scroll trace table to latest
  useEffect(() => {
    if (traceTableRef.current && snapshot.status === 'running') {
      traceTableRef.current.scrollTop = traceTableRef.current.scrollHeight;
    }
  }, [traces.length, snapshot.status]);

  const filteredTraces = traceSearch
    ? traces.filter(
        (t) =>
          t.mnemonic.toLowerCase().includes(traceSearch.toLowerCase()) ||
          t.comment?.toLowerCase().includes(traceSearch.toLowerCase()) ||
          String(t.pc).includes(traceSearch) ||
          String(t.step).includes(traceSearch)
      )
    : traces;

  const isCustomProgram = !SAMPLE_PROGRAMS.some((p) => p.id === selectedProgram.id);

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Control Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-2.5 border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm shrink-0">
        {/* Left: Program Selection & Arguments */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label className="text-xs font-medium text-slate-400">Problem / Code:</label>
            <select
              value={selectedProgram.id}
              onChange={(e) => {
                const found = SAMPLE_PROGRAMS.find((p) => p.id === e.target.value);
                if (found) {
                  onProgramChange(found);
                }
              }}
              className="bg-slate-950 border border-slate-700 rounded-md px-3 py-1.5 text-xs font-medium text-slate-100 focus:outline-none focus:border-indigo-500 transition-colors max-w-[280px] truncate"
            >
              {isCustomProgram && (
                <optgroup label="Custom User Program">
                  <option value={selectedProgram.id}>
                    ★ {selectedProgram.name} ({selectedProgram.className}.{selectedProgram.methodName})
                  </option>
                </optgroup>
              )}
              <optgroup label="LeetCode Interview Problems">
                {SAMPLE_PROGRAMS.filter((p) => p.category === 'leetcode' || p.leetcodeId !== undefined).map((p) => (
                  <option key={p.id} value={p.id}>
                    LC #{p.leetcodeId} [{p.difficulty}] {p.name.replace(/^LeetCode\s+\d+:\s*/, '')}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Math & Numbers">
                {SAMPLE_PROGRAMS.filter((p) => p.category === 'math').map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.className}.{p.methodName})
                  </option>
                ))}
              </optgroup>
              <optgroup label="Algorithms & Searching">
                {SAMPLE_PROGRAMS.filter((p) => p.category === 'algo').map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.className}.{p.methodName})
                  </option>
                ))}
              </optgroup>
              <optgroup label="Heap Memory & Arrays">
                {SAMPLE_PROGRAMS.filter((p) => p.category === 'heap').map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.className}.{p.methodName})
                  </option>
                ))}
              </optgroup>
              <optgroup label="Recursion & Call Stack">
                {SAMPLE_PROGRAMS.filter((p) => p.category === 'recursion').map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.className}.{p.methodName})
                  </option>
                ))}
              </optgroup>
              <optgroup label="Bitwise & Low-Level">
                {SAMPLE_PROGRAMS.filter((p) => p.category === 'bitwise').map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.className}.{p.methodName})
                  </option>
                ))}
              </optgroup>
            </select>
          </div>

          {onOpenLeetCode && (
            <button
              onClick={onOpenLeetCode}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold bg-amber-950/80 hover:bg-amber-900/80 text-amber-300 border border-amber-700/60 rounded-md transition-colors shadow-sm"
              title="Browse all LeetCode problems with filters and test suites"
            >
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>LeetCode Library</span>
            </button>
          )}

          {onEditInAssembler && (
            <button
              onClick={onEditInAssembler}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 border border-slate-700 rounded-md transition-colors shadow-sm"
              title="Open this program in the Bytecode Assembler to edit or customize"
            >
              <Code className="w-3.5 h-3.5" />
              <span>Customize Code</span>
            </button>
          )}

          {/* Test Cases Quick Selector */}
          {selectedProgram.testCases && selectedProgram.testCases.length > 0 && (
            <div className="flex items-center gap-1 bg-slate-900/90 px-2 py-1 rounded border border-slate-800 text-xs">
              <span className="text-[10px] text-slate-500 font-mono">Test Cases:</span>
              {selectedProgram.testCases.map((tc, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    onArgsChange([...tc.args]);
                    onReset();
                  }}
                  className="px-2 py-0.5 rounded text-[11px] font-mono bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700 transition-colors"
                  title={`${tc.name}: args [${tc.args.join(', ')}], expected ${tc.expected}`}
                >
                  Case {idx + 1}
                </button>
              ))}
            </div>
          )}

          {/* Program Arguments */}
          {selectedProgram.argLabels.map((lbl, idx) => (
            <div key={idx} className="flex items-center gap-1.5">
              <span className="text-xs text-slate-400 font-mono">{lbl}:</span>
              <input
                type="number"
                value={programArgs[idx] ?? 0}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10) || 0;
                  const newArgs = [...programArgs];
                  newArgs[idx] = val;
                  onArgsChange(newArgs);
                }}
                disabled={snapshot.status === 'running'}
                className="w-16 bg-slate-950 border border-slate-700 rounded-md px-2 py-1 text-xs font-mono text-center text-slate-100 focus:outline-none focus:border-emerald-500 disabled:opacity-50"
              />
            </div>
          ))}
        </div>

        {/* Center: Execution Stepper Controls & Architecture Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowArchitectureArt(!showArchitectureArt)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md border transition-colors ${
              showArchitectureArt
                ? 'bg-indigo-950 text-indigo-300 border-indigo-600'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
            title="Toggle interactive JVM silicon architecture circuit map"
          >
            <Cpu className="w-3.5 h-3.5 text-indigo-400" />
            <span>Architecture Map</span>
          </button>

          <button
            onClick={() => setShowD3Modal(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md border bg-slate-800 text-pink-300 border-pink-700/60 hover:bg-slate-700 transition-colors shadow-xs"
            title="Open real-time interactive D3.js JVM Heap Visualizer"
          >
            <HardDrive className="w-3.5 h-3.5 text-pink-400" />
            <span>D3 Heap Graph</span>
            {(snapshot.heapArrays.length > 0 || snapshot.heapObjects.length > 0) && (
              <span className="w-2 h-2 rounded-full bg-pink-400 animate-pulse" />
            )}
          </button>

          {snapshot.status === 'running' ? (
            <button
              onClick={onPause}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-amber-600 text-white rounded-md hover:bg-amber-500 transition-colors shadow-sm"
            >
              <Pause className="w-3.5 h-3.5" />
              Pause
            </button>
          ) : (
            <button
              onClick={onRun}
              disabled={snapshot.status === 'completed' || snapshot.status === 'error'}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium bg-emerald-600 text-white rounded-md hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 transition-colors shadow-sm"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              Run / Resume
            </button>
          )}

          <button
            onClick={onStep}
            disabled={snapshot.status === 'running' || snapshot.status === 'completed'}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-800 border border-slate-700 text-slate-100 rounded-md hover:bg-slate-700 disabled:opacity-40 transition-colors"
            title="Execute single instruction (Fetch-Decode-Execute)"
          >
            <SkipForward className="w-3.5 h-3.5 text-emerald-400" />
            Step Into (F7)
          </button>

          <button
            onClick={onReset}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-800 border border-slate-700 text-slate-300 rounded-md hover:bg-slate-700 hover:text-white transition-colors"
            title="Reset VM State, Stack Frames & Heap"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset
          </button>

          {/* Speed Selector */}
          <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-slate-800 text-xs text-slate-400">
            <span>Delay:</span>
            <select
              value={speedMs}
              onChange={(e) => onSpeedChange(Number(e.target.value))}
              className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs text-slate-300 font-mono focus:outline-none"
            >
              <option value={50}>Fast (50ms)</option>
              <option value={200}>Normal (200ms)</option>
              <option value={500}>Deliberate (500ms)</option>
              <option value={1000}>Slow-motion (1s)</option>
              <option value={0}>Instant (0ms)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Collapsible Architecture Map */}
      {showArchitectureArt && (
        <div className="p-4 border-b border-slate-800 bg-slate-950/95 shrink-0">
          <JvmArchitectureArt snapshot={snapshot} activePc={snapshot.pc} compact />
        </div>
      )}

      {/* Main 3-Column Diagnostic Workspace */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-0 overflow-hidden divide-y lg:divide-y-0 lg:divide-x divide-slate-800">
        {/* Column 1: Bytecode & Disassembly Viewer (4 cols) */}
        <div className="lg:col-span-4 flex flex-col h-full bg-slate-950/60 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-900/40 text-xs font-semibold text-slate-300">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Bytecode Disassembler</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono text-slate-500">
                {instructions.length} instrs · {selectedProgram.className}.{selectedProgram.methodName}
              </span>
              {onEditInAssembler && (
                <button
                  onClick={onEditInAssembler}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-emerald-400 transition-colors bg-slate-900 hover:bg-slate-800 px-2 py-0.5 rounded border border-slate-800"
                  title="Open this program in the Bytecode Assembler"
                >
                  <Code className="w-3 h-3" />
                  <span>Edit</span>
                </button>
              )}
            </div>
          </div>

          <div
            ref={bytecodeContainerRef}
            className="flex-1 overflow-y-auto p-2 font-mono text-xs select-none space-y-0.5"
          >
            {instructions.map((instr) => {
              const isActive = snapshot.pc === instr.offset && snapshot.status !== 'completed';
              const isBreakpoint = snapshot.breakpoints.has(instr.offset);

              return (
                <div
                  key={instr.offset}
                  data-active-pc={isActive}
                  onClick={() => onToggleBreakpoint(instr.offset)}
                  className={`group flex items-center gap-2 px-2.5 py-1.5 rounded cursor-pointer transition-colors ${
                    isActive
                      ? 'bg-emerald-950/60 border border-emerald-500/50 text-emerald-200 font-semibold'
                      : 'hover:bg-slate-900/80 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {/* Breakpoint Indicator */}
                  <div
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 transition-opacity ${
                      isBreakpoint
                        ? 'bg-red-500 text-white'
                        : 'opacity-0 group-hover:opacity-40 border border-slate-600'
                    }`}
                  >
                    {isBreakpoint && <span className="w-1.5 h-1.5 bg-white rounded-full" />}
                  </div>

                  {/* Active PC Indicator Arrow */}
                  <div className="w-4 text-center shrink-0">
                    {isActive ? (
                      <ArrowRight className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                    ) : (
                      <span className="text-slate-600 text-[10px]"></span>
                    )}
                  </div>

                  {/* Offset */}
                  <span className="w-10 text-slate-500 text-[11px] tabular-nums shrink-0">
                    {String(instr.offset).padStart(4, '0')}
                  </span>

                  {/* Hex opcode byte */}
                  <span className="w-8 text-slate-600 text-[10px] tabular-nums shrink-0">
                    0x{instr.opcode.toString(16).padStart(2, '0').toUpperCase()}
                  </span>

                  {/* Mnemonic */}
                  <span
                    className={`w-24 shrink-0 font-bold ${
                      isActive
                        ? 'text-emerald-300'
                        : instr.category === 'branch'
                        ? 'text-amber-400'
                        : instr.category === 'invoke'
                        ? 'text-purple-400'
                        : instr.category === 'math'
                        ? 'text-cyan-400'
                        : instr.category === 'array'
                        ? 'text-pink-400'
                        : 'text-slate-200'
                    }`}
                  >
                    {instr.mnemonic}
                  </span>

                  {/* Operands */}
                  <span className="w-16 text-slate-300 shrink-0 tabular-nums">
                    {instr.operands.join(' ')}
                  </span>

                  {/* Comment or branch target */}
                  {instr.comment && (
                    <span className="text-slate-500 text-[11px] truncate italic">
                      // {instr.comment}
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Interactive Equivalent Java Source Code Editor */}
          <div className="p-3 border-t border-slate-800 bg-slate-900/40 shrink-0">
            <div className="flex items-center justify-between gap-2 mb-2">
              <div className="flex items-center gap-1.5">
                <Code className="w-3.5 h-3.5 text-indigo-400" />
                <span className="text-[11px] font-semibold text-slate-300">
                  Equivalent Java Source Code
                </span>
                {isEditingJava && (
                  <span className="text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-700/60 px-1.5 py-0.2 rounded font-mono">
                    EDITING
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 text-xs">
                {!isEditingJava ? (
                  <>
                    <button
                      onClick={() => setIsEditingJava(true)}
                      className="flex items-center gap-1 px-2 py-0.5 bg-indigo-600/30 hover:bg-indigo-600 text-indigo-200 hover:text-white rounded text-[11px] font-medium border border-indigo-500/40 transition-colors"
                      title="Edit this Java algorithm directly"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>Edit Java</span>
                    </button>
                    {onEditInAssembler && (
                      <button
                        onClick={onEditInAssembler}
                        className="flex items-center gap-1 px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] border border-slate-700 transition-colors"
                        title="Open in full assembler studio"
                      >
                        <FileCode className="w-3 h-3 text-slate-400" />
                        <span>Studio</span>
                      </button>
                    )}
                  </>
                ) : (
                  <>
                    <button
                      onClick={handleApplyJavaEdit}
                      className="flex items-center gap-1 px-2.5 py-0.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-semibold transition-colors shadow-sm"
                      title="Compile Java to Bytecode and update JVM"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Compile & Update VM</span>
                    </button>
                    <button
                      onClick={() => {
                        setEditedJavaSource(selectedProgram.javaSourceSnippet);
                        setJavaCompileError(null);
                        setJavaCompileSuccess(false);
                      }}
                      className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded text-[11px] border border-slate-700 transition-colors"
                      title="Revert to original snippet"
                    >
                      Revert
                    </button>
                    <button
                      onClick={() => setIsEditingJava(false)}
                      className="px-2 py-0.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded text-[11px] border border-slate-800 transition-colors"
                    >
                      Done
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Error or Success notification */}
            {javaCompileError && (
              <div className="mb-2 p-2 bg-rose-950/80 border border-rose-800/80 rounded text-[11px] font-mono text-rose-300 flex items-start gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                <span className="leading-tight">{javaCompileError}</span>
              </div>
            )}
            {javaCompileSuccess && (
              <div className="mb-2 p-1.5 bg-emerald-950/80 border border-emerald-800/80 rounded text-[11px] font-mono text-emerald-300 flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Java compiled successfully & bytecode loaded into JVM!</span>
              </div>
            )}

            {isEditingJava ? (
              <textarea
                value={editedJavaSource}
                onChange={(e) => setEditedJavaSource(e.target.value)}
                rows={9}
                className="w-full text-[11px] font-mono text-indigo-100 bg-slate-950 p-2.5 rounded border border-indigo-500/60 focus:outline-none focus:border-indigo-400 leading-relaxed resize-y"
                placeholder="Write standard Java method..."
                spellCheck={false}
              />
            ) : (
              <div className="relative group">
                <pre className="text-[11px] font-mono text-slate-300 bg-slate-950 p-2.5 rounded border border-slate-800/80 overflow-x-auto leading-relaxed max-h-48">
                  {selectedProgram.javaSourceSnippet}
                </pre>
                <button
                  onClick={() => setIsEditingJava(true)}
                  className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity px-2 py-1 bg-indigo-900/80 hover:bg-indigo-800 text-indigo-200 rounded text-[10px] font-sans flex items-center gap-1 shadow-sm"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>Click to Edit</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Column 2: Runtime Data Areas & Stack Frame Inspector (4 cols) */}
        <div className="lg:col-span-4 flex flex-col h-full bg-slate-950 overflow-y-auto divide-y divide-slate-800">
          {/* Section A: PC Register & Thread State */}
          <div className="p-4 bg-slate-900/30">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-emerald-400" />
                PC Register & Call Frame
              </span>
              <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-2 py-0.5 rounded">
                PC = {snapshot.pc} (0x{snapshot.pc.toString(16).padStart(4, '0').toUpperCase()})
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">ACTIVE METHOD</span>
                <span className="text-slate-200 font-semibold truncate block">
                  {snapshot.currentFrame ? snapshot.currentFrame.methodName : selectedProgram.methodName}
                </span>
                <span className="text-[10px] text-slate-400 block truncate">
                  {selectedProgram.descriptor}
                </span>
              </div>

              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">STACK DEPTH</span>
                <span className="text-slate-200 font-semibold tabular-nums">
                  {snapshot.callStack.length} frame(s)
                </span>
                <span className="text-[10px] text-slate-400 block">
                  Max Stack: {selectedProgram.maxStack} slots
                </span>
              </div>
            </div>

            {/* Return Value Banner */}
            {snapshot.status === 'completed' && snapshot.returnValue && (() => {
              const matchingTest = selectedProgram.testCases?.find((tc) =>
                JSON.stringify(tc.args) === JSON.stringify(programArgs)
              );
              const isTestMatch = matchingTest && snapshot.returnValue.value === matchingTest.expected;
              const isTestFail = matchingTest && snapshot.returnValue.value !== matchingTest.expected;

              return (
                <div
                  className={`mt-3 p-3 rounded-lg border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs shadow-sm transition-all ${
                    isTestMatch
                      ? 'bg-emerald-950/90 border-emerald-500/60 text-emerald-200'
                      : isTestFail
                      ? 'bg-rose-950/90 border-rose-500/60 text-rose-200'
                      : 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle className={`w-4 h-4 shrink-0 ${isTestFail ? 'text-rose-400' : 'text-emerald-400'}`} />
                    <span className="font-medium">
                      {matchingTest
                        ? isTestMatch
                          ? `Passed ${matchingTest.name}!`
                          : `Failed ${matchingTest.name} (Expected: ${matchingTest.expected})`
                        : 'Execution Completed'}
                    </span>
                  </div>
                  <span className="font-mono font-bold text-sm text-white bg-slate-950/80 px-2.5 py-0.5 rounded border border-slate-800">
                    Return = {snapshot.returnValue.type === 'REFERENCE' ? `@0x${snapshot.returnValue.value.toString(16).toUpperCase()}` : snapshot.returnValue.value}
                  </span>
                </div>
              );
            })()}

            {snapshot.status === 'error' && (
              <div className="mt-3 p-2.5 bg-red-950/80 border border-red-500/50 rounded flex items-center gap-2 text-xs text-red-200">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{snapshot.errorMessage}</span>
              </div>
            )}
          </div>

          {/* Section B: Operand Stack (LIFO) */}
          <div className="p-4 flex-1">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded bg-cyan-400" />
                Operand Stack (LIFO)
              </span>
              <span className="text-[11px] font-mono text-slate-400 tabular-nums">
                {snapshot.operandStack.length} / {selectedProgram.maxStack} slots
              </span>
            </div>

            {snapshot.operandStack.length === 0 ? (
              <div className="py-6 border border-dashed border-slate-800 rounded-lg text-center text-xs text-slate-500 font-mono">
                [ Empty Operand Stack ]
              </div>
            ) : (
              <div className="space-y-1 font-mono text-xs">
                {/* Render stack top down */}
                {snapshot.operandStack
                  .slice()
                  .reverse()
                  .map((item, reverseIdx) => {
                    const actualIdx = snapshot.operandStack.length - 1 - reverseIdx;
                    const isTop = reverseIdx === 0;

                    return (
                      <div
                        key={actualIdx}
                        className={`flex items-center justify-between px-3 py-2 rounded border transition-all ${
                          isTop
                            ? 'bg-cyan-950/60 border-cyan-500/60 text-cyan-200 font-bold shadow-sm'
                            : 'bg-slate-900 border-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500 text-[10px] w-6">#{actualIdx}</span>
                          <span className="px-1.5 py-0.5 text-[9px] rounded bg-slate-800 text-slate-400 font-semibold">
                            {item.type}
                          </span>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="text-sm font-semibold tabular-nums">
                            {item.type === 'REFERENCE'
                              ? `@0x${item.value.toString(16).toUpperCase()}`
                              : item.value}
                          </span>
                          {isTop && (
                            <span className="text-[10px] font-sans px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-medium">
                              TOP (TOS)
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>

          {/* Section C: Local Variable Table (LVT) */}
          <div className="p-4 bg-slate-900/20">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded bg-amber-400" />
                Local Variable Table (LVT)
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                {selectedProgram.maxLocals} slots
              </span>
            </div>

            <div className="grid grid-cols-1 gap-1.5 font-mono text-xs">
              {Array.from({ length: selectedProgram.maxLocals }).map((_, slotIdx) => {
                const val = snapshot.localVariables[slotIdx];
                return (
                  <div
                    key={slotIdx}
                    className="flex items-center justify-between px-3 py-1.5 bg-slate-950 rounded border border-slate-800 text-slate-300"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-amber-400 font-bold text-xs w-6">
                        [{slotIdx}]
                      </span>
                      <span className="text-slate-400 text-xs">
                        slot {slotIdx}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-500 font-mono">
                        {val ? val.type : 'UNINIT'}
                      </span>
                      <span className="font-semibold text-slate-100 tabular-nums">
                        {val
                          ? val.type === 'REFERENCE'
                            ? `@0x${val.value.toString(16).toUpperCase()}`
                            : val.value
                          : '0'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section D: Call Stack Frames (Nested recursion trace) */}
          {snapshot.callStack.length > 1 && (
            <div className="p-4 bg-slate-950">
              <div className="text-xs font-semibold text-purple-400 mb-2 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                Active Call Stack Frames ({snapshot.callStack.length})
              </div>
              <div className="space-y-1 font-mono text-xs">
                {snapshot.callStack
                  .slice()
                  .reverse()
                  .map((frame, revIdx) => {
                    const depth = snapshot.callStack.length - revIdx;
                    return (
                      <div
                        key={frame.id}
                        className={`px-3 py-1.5 rounded border text-xs flex items-center justify-between ${
                          revIdx === 0
                            ? 'bg-purple-950/60 border-purple-500/50 text-purple-200'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        <span className="truncate">
                          #{depth} {frame.className}.{frame.methodName}(n={frame.localVariableTable[0]?.value ?? '?'})
                        </span>
                        <span className="text-[10px] text-slate-500">PC {frame.pc}</span>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}
        </div>

        {/* Column 3: Heap Memory, Constant Pool & Console (4 cols) */}
        <div className="lg:col-span-4 flex flex-col h-full bg-slate-950 overflow-y-auto divide-y divide-slate-800">
          {/* Heap Memory Section with D3 Visualizer */}
          <div className="p-4 space-y-2">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5 text-pink-400" />
                Heap Memory Area (D3 Real-Time)
              </span>

              <div className="flex items-center gap-1.5 text-xs">
                <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 text-[10px]">
                  <button
                    onClick={() => setHeapDisplayMode('d3')}
                    className={`px-2 py-0.5 rounded transition-colors ${
                      heapDisplayMode === 'd3'
                        ? 'bg-pink-950 text-pink-300 font-semibold border border-pink-800/50'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    D3 Graph
                  </button>
                  <button
                    onClick={() => setHeapDisplayMode('raw')}
                    className={`px-2 py-0.5 rounded transition-colors ${
                      heapDisplayMode === 'raw'
                        ? 'bg-slate-800 text-slate-200 font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Raw Cells
                  </button>
                </div>

                <button
                  onClick={() => setShowD3Modal(true)}
                  className="p-1 hover:bg-slate-800 text-slate-400 hover:text-pink-300 rounded border border-slate-800 transition-colors"
                  title="Expand D3 Heap Visualizer fullscreen"
                >
                  <Maximize2 className="w-3 h-3" />
                </button>
              </div>
            </div>

            {heapDisplayMode === 'd3' ? (
              <JvmHeapD3Visualizer snapshot={snapshot} />
            ) : (
              snapshot.heapArrays.length === 0 && snapshot.heapObjects.length === 0 ? (
                <div className="py-4 border border-dashed border-slate-800 rounded-lg text-center text-xs text-slate-500 font-mono">
                  No active heap allocations
                </div>
              ) : (
                <div className="space-y-2 font-mono text-xs">
                  {snapshot.heapArrays.map((arr) => (
                    <div
                      key={arr.address}
                      className="p-2.5 bg-slate-900/60 border border-slate-800 rounded space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-pink-300">
                        <span className="font-bold">
                          Array@0x{arr.address.toString(16).toUpperCase()}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          int[{arr.length}]
                        </span>
                      </div>

                      <div className="flex flex-wrap gap-1 text-[11px]">
                        {arr.elements.map((el, elIdx) => (
                          <div
                            key={elIdx}
                            className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-slate-200"
                          >
                            <span className="text-slate-500 text-[9px] mr-1">[{elIdx}]</span>
                            <span className="tabular-nums font-semibold">{el}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )
            )}
          </div>

          {/* Constant Pool Section */}
          <div className="p-4 bg-slate-900/20">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-emerald-400" />
                Runtime Constant Pool
              </span>
              <span className="text-[11px] font-mono text-slate-500">
                {selectedProgram.constantPool.length} entries
              </span>
            </div>

            <div className="space-y-1 font-mono text-xs max-h-48 overflow-y-auto pr-1">
              {selectedProgram.constantPool.map((cp) => (
                <div
                  key={cp.index}
                  className="flex items-center justify-between px-2.5 py-1 bg-slate-950 rounded border border-slate-800/80 text-[11px]"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400 font-bold w-6">#{cp.index}</span>
                    <span className="text-slate-400 text-[10px]">{cp.tag}</span>
                  </div>
                  <span className="text-slate-200 truncate max-w-[180px]">
                    {String(cp.value)} {cp.descriptor ? `(${cp.descriptor})` : ''}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Virtual Console / System.out */}
          <div className="p-4 flex-1 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-slate-400" />
                Virtual Console (System.out)
              </span>
              <span className="text-[10px] font-mono text-slate-500">
                stdout stream
              </span>
            </div>

            <div className="flex-1 min-h-[100px] p-2.5 bg-slate-950 rounded border border-slate-800 font-mono text-xs overflow-y-auto">
              {snapshot.stdout.length === 0 ? (
                <span className="text-slate-600 italic">No output written yet.</span>
              ) : (
                snapshot.stdout.map((line, idx) => (
                  <div key={idx} className="text-emerald-400">
                    &gt; {line}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: Step-by-Step Execution Trace Table */}
      <div className="h-64 border-t border-slate-800 bg-slate-950 flex flex-col shrink-0">
        <div className="flex items-center justify-between px-6 py-2 border-b border-slate-800 bg-slate-900/60 text-xs">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-200 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              Step-by-Step Execution Trace Log
            </span>
            <span className="text-slate-500 font-mono tabular-nums">
              ({traces.length} steps recorded)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={traceSearch}
                onChange={(e) => setTraceSearch(e.target.value)}
                placeholder="Filter instructions or notes..."
                className="w-56 bg-slate-950 border border-slate-700 rounded-md pl-8 pr-3 py-1 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        </div>

        <div ref={traceTableRef} className="flex-1 overflow-auto font-mono text-xs">
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 bg-slate-900 text-[11px] text-slate-400 border-b border-slate-800 uppercase tracking-wider select-none">
              <tr>
                <th className="py-2 px-4 w-16">Step</th>
                <th className="py-2 px-3 w-16">PC</th>
                <th className="py-2 px-4 w-32">Instruction</th>
                <th className="py-2 px-4 w-44">Operand Stack</th>
                <th className="py-2 px-4 w-52">Local Variable Table</th>
                <th className="py-2 px-4">Method & Dynamic Context</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900">
              {filteredTraces.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-600">
                    No execution steps yet. Click "Run" or "Step Into" to begin execution.
                  </td>
                </tr>
              ) : (
                filteredTraces.map((trace) => (
                  <tr
                    key={trace.step}
                    className="hover:bg-slate-900/50 transition-colors text-slate-300"
                  >
                    <td className="py-1.5 px-4 text-slate-500 tabular-nums">
                      #{trace.step}
                    </td>
                    <td className="py-1.5 px-3 text-emerald-400 font-semibold tabular-nums">
                      {trace.pc}
                    </td>
                    <td className="py-1.5 px-4 font-bold text-slate-100">
                      {trace.mnemonic} {trace.operands.join(' ')}
                    </td>
                    <td className="py-1.5 px-4 text-cyan-300">
                      [{trace.stackAfter.map((s) => (s.type === 'REFERENCE' ? `@0x${s.value.toString(16).toUpperCase()}` : s.value)).join(', ')}]
                    </td>
                    <td className="py-1.5 px-4 text-amber-300">
                      {'{'}
                      {trace.lvtSnapshot
                        .map((l, i) => (l ? `${i}:${l.type === 'REFERENCE' ? `@0x${l.value.toString(16).toUpperCase()}` : l.value}` : null))
                        .filter(Boolean)
                        .join(', ')}
                      {'}'}
                    </td>
                    <td className="py-1.5 px-4 text-slate-400">
                      <span className="text-slate-500 mr-2">{trace.method}</span>
                      {trace.comment && (
                        <span className="text-slate-300 italic">// {trace.comment}</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Fullscreen D3 Heap Visualizer Modal */}
      {showD3Modal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-700/80 rounded-xl w-full h-[90vh] max-w-6xl flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-900/80">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-pink-400" />
                <span className="font-bold text-sm text-white">
                  Real-Time JVM Heap & Reference Topology (D3.js)
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-pink-950 text-pink-300 border border-pink-700/60">
                  PC: {snapshot.pc} · Step: {snapshot.stepCount}
                </span>
              </div>
              <button
                onClick={() => setShowD3Modal(false)}
                className="px-2.5 py-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded text-xs font-mono transition-colors"
              >
                Close (ESC)
              </button>
            </div>
            <div className="flex-1 overflow-hidden p-2">
              <JvmHeapD3Visualizer snapshot={snapshot} isExpandedDefault={false} className="h-full" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
