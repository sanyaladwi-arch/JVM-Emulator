import React from 'react';
import { Cpu, Terminal, FileCode, BookOpen, Download, Trophy } from 'lucide-react';

export type ActiveTab = 'debugger' | 'editor' | 'leetcode' | 'codebase' | 'specs';

interface TopNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  onQuickReset?: () => void;
  onDownloadZip?: () => void;
  status: 'idle' | 'running' | 'paused' | 'completed' | 'error';
  stepCount: number;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeTab,
  onTabChange,
  onDownloadZip,
  status,
  stepCount,
}) => {
  return (
    <header className="flex items-center justify-between gap-6 px-6 py-3 border-b border-slate-800/90 bg-slate-950/95 backdrop-blur-md text-slate-100 select-none z-20">
      {/* Brand Identity Wordmark & Silicon Node */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="relative">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500/20 via-purple-500/10 to-emerald-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shadow-inner">
            <Cpu className="w-4 h-4" />
          </div>
          <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-950" />
        </div>
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold tracking-tight text-white whitespace-nowrap">
              JVM Bytecode Emulator
            </span>
            <span className="text-[10px] bg-indigo-950/80 text-indigo-300 border border-indigo-800/60 px-1.5 py-0.2 rounded font-mono font-medium">
              v17 Architecture
            </span>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            Fetch-Decode-Execute · D3 Real-Time Heap · LeetCode Studio
          </span>
        </div>
      </div>

      {/* Main Navigation Segmented Tabs */}
      <nav className="hidden md:flex items-center gap-1 p-1 bg-slate-900/90 border border-slate-800 rounded-lg text-xs font-medium text-slate-400">
        <button
          onClick={() => onTabChange('debugger')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'debugger'
              ? 'bg-slate-800 text-emerald-400 font-semibold shadow-sm'
              : 'hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>Execution Debugger</span>
        </button>

        <button
          onClick={() => onTabChange('leetcode')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'leetcode'
              ? 'bg-slate-800 text-amber-400 font-semibold shadow-sm'
              : 'hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Trophy className="w-3.5 h-3.5 text-amber-400" />
          <span>LeetCode Problems</span>
          <span className="text-[9px] bg-amber-950/80 text-amber-400 border border-amber-800 px-1.5 py-0.2 rounded font-mono">
            16
          </span>
        </button>

        <button
          onClick={() => onTabChange('editor')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'editor'
              ? 'bg-slate-800 text-cyan-400 font-semibold shadow-sm'
              : 'hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>Bytecode Studio</span>
        </button>

        <button
          onClick={() => onTabChange('specs')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'specs'
              ? 'bg-slate-800 text-indigo-400 font-semibold shadow-sm'
              : 'hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Memory & Architecture</span>
        </button>

        <button
          onClick={() => onTabChange('codebase')}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'codebase'
              ? 'bg-slate-800 text-purple-400 font-semibold shadow-sm'
              : 'hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>Java Maven Tree</span>
        </button>
      </nav>

      {/* Right Action Bar & Cycle Counter */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="hidden lg:flex items-center gap-2 text-xs text-slate-400 font-mono tabular-nums bg-slate-900/60 px-2.5 py-1 rounded-md border border-slate-800">
          <span className="text-slate-500">CYCLE:</span>
          <span className="text-slate-200 font-semibold">{stepCount}</span>
          <span className="text-slate-600">·</span>
          <span className="text-slate-500">STATE:</span>
          <span
            className={
              status === 'completed'
                ? 'text-emerald-400 font-semibold'
                : status === 'running'
                ? 'text-amber-400 font-semibold'
                : status === 'error'
                ? 'text-rose-400 font-semibold'
                : 'text-slate-300'
            }
          >
            {status.toUpperCase()}
          </span>
        </div>

        {onDownloadZip && (
          <button
            onClick={onDownloadZip}
            className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 border border-slate-700/80 rounded-lg hover:bg-slate-800 hover:border-slate-600 transition-colors whitespace-nowrap shadow-sm"
            title="Download complete Maven project with all Java sources as ZIP"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Export ZIP</span>
          </button>
        )}
      </div>
    </header>
  );
};
