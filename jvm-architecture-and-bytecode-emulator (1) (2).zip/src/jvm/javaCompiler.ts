/**
 * Robust Micro-Java to JVM Bytecode Transpiler
 * Allows programmers to write standard Java algorithmic solutions
 * (variables, for/while loops, if/else, array allocation, Math.max/min, ternary, return)
 * and smoothly compiles them into valid JVM bytecode assembly mnemonics.
 */

export interface CompileResult {
  success: boolean;
  assemblySource: string;
  errorMessage?: string;
  errorLine?: number;
}

interface LoopContext {
  startLabel: string;
  endLabel: string;
  stepLabel?: string;
}

export class JavaCompiler {
  /**
   * Detects whether the input string is Java source code or raw JVM bytecode assembly.
   */
  static isJavaSource(code: string): boolean {
    const trimmed = code.trim();
    if (!trimmed) return false;

    // Common Java signatures or keywords
    if (
      /\b(public|private|protected|static|class|int|boolean|void|while|for|if|return)\b/.test(trimmed) &&
      (trimmed.includes('{') || trimmed.includes('(') || trimmed.includes(';'))
    ) {
      const bytecodeTokens = ['iload', 'istore', 'iconst', 'bipush', 'iadd', 'ireturn', 'goto', 'newarray', 'invokestatic'];
      const firstLines = trimmed.split('\n').slice(0, 5).join(' ');
      const hasJavaMethodHeader = /(?:public\s+|static\s+|private\s+)*(?:int|void|boolean)\s+\w+\s*\(/.test(firstLines);
      if (hasJavaMethodHeader) return true;

      let bytecodeScore = 0;
      for (const tok of bytecodeTokens) {
        if (new RegExp(`\\b${tok}\\b`).test(trimmed)) bytecodeScore++;
      }
      return bytecodeScore < 2;
    }
    return false;
  }

  /**
   * Compiles Java algorithmic methods into JVM bytecode assembly.
   */
  static compile(javaCode: string): CompileResult {
    try {
      const varMap = new Map<string, number>(); // varName -> slot
      let nextSlot = 0;
      let labelId = 1;
      const loopStack: LoopContext[] = [];

      // 1. Extract parameters from method header if present
      const headerMatch = javaCode.match(/(?:public\s+|static\s+|private\s+)*(?:int|void|boolean)\s+(\w+)\s*\(([^)]*)\)/);
      if (headerMatch) {
        const paramStr = headerMatch[2].trim();
        if (paramStr) {
          const params = paramStr.split(',');
          for (const param of params) {
            const parts = param.trim().split(/\s+/);
            const pName = parts[parts.length - 1].replace(/[\[\]]/g, '').trim();
            if (pName) {
              varMap.set(pName, nextSlot++);
            }
          }
        }
      }

      // 2. Extract body between outermost { and }
      const firstBrace = javaCode.indexOf('{');
      const lastBrace = javaCode.lastIndexOf('}');
      const body = firstBrace !== -1 && lastBrace !== -1
        ? javaCode.substring(firstBrace + 1, lastBrace)
        : javaCode;

      const outputLines: string[] = [];

      const getLabel = (prefix: string) => `L_${prefix}_${labelId++}`;
      const compileBranchCondition = (c: string, t: string, inv: boolean, vm: Map<string, number>) =>
        JavaCompiler.compileBranchCondition(c, t, inv, vm);
      const compileExpression = (e: string, vm: Map<string, number>) =>
        JavaCompiler.compileExpression(e, vm);

      // Helper to compile a block of statements
      const compileBlock = (codeBlock: string) => {
        let text = codeBlock.trim();

        while (text.length > 0) {
          text = text.trim();
          if (!text) break;

          // Strip comments
          if (text.startsWith('//')) {
            const nextNewline = text.indexOf('\n');
            if (nextNewline === -1) break;
            text = text.substring(nextNewline + 1);
            continue;
          }
          if (text.startsWith('/*')) {
            const endComment = text.indexOf('*/');
            if (endComment === -1) break;
            text = text.substring(endComment + 2);
            continue;
          }

          // 1. while (condition) { body } or while (condition) stmt;
          const whileMatch = text.match(/^while\s*\(([^)]+)\)/);
          if (whileMatch) {
            const cond = whileMatch[1].trim();
            const afterHeader = text.substring(whileMatch[0].length).trim();
            const loopStart = getLabel('WHILE_START');
            const loopEnd = getLabel('WHILE_END');

            let bodyCode = '';
            let remaining = '';

            if (afterHeader.startsWith('{')) {
              const bodyRange = findMatchingBrace(afterHeader, 0);
              bodyCode = bodyRange.content;
              remaining = bodyRange.after;
            } else {
              const semiIdx = afterHeader.indexOf(';');
              if (semiIdx !== -1) {
                bodyCode = afterHeader.substring(0, semiIdx + 1);
                remaining = afterHeader.substring(semiIdx + 1);
              } else {
                bodyCode = afterHeader;
                remaining = '';
              }
            }

            outputLines.push(`${loopStart}:`);
            outputLines.push(...compileBranchCondition(cond, loopEnd, true, varMap));

            loopStack.push({ startLabel: loopStart, endLabel: loopEnd });
            compileBlock(bodyCode);
            loopStack.pop();

            outputLines.push(`goto ${loopStart}`);
            outputLines.push(`${loopEnd}:`);
            text = remaining;
            continue;
          }

          // 2. for (init; cond; step) { body }
          const forMatch = text.match(/^for\s*\(([^;]*);([^;]*);([^)]*)\)/);
          if (forMatch) {
            const initPart = forMatch[1].trim();
            const condPart = forMatch[2].trim();
            const stepPart = forMatch[3].trim();
            const afterHeader = text.substring(forMatch[0].length).trim();

            const loopStart = getLabel('FOR_START');
            const loopStep = getLabel('FOR_STEP');
            const loopEnd = getLabel('FOR_END');

            let bodyCode = '';
            let remaining = '';

            if (afterHeader.startsWith('{')) {
              const bodyRange = findMatchingBrace(afterHeader, 0);
              bodyCode = bodyRange.content;
              remaining = bodyRange.after;
            } else {
              const semiIdx = afterHeader.indexOf(';');
              if (semiIdx !== -1) {
                bodyCode = afterHeader.substring(0, semiIdx + 1);
                remaining = afterHeader.substring(semiIdx + 1);
              } else {
                bodyCode = afterHeader;
                remaining = '';
              }
            }

            // Init
            if (initPart) {
              compileStatement(initPart + ';');
            }

            outputLines.push(`${loopStart}:`);
            if (condPart) {
              outputLines.push(...compileBranchCondition(condPart, loopEnd, true, varMap));
            }

            loopStack.push({ startLabel: loopStart, endLabel: loopEnd, stepLabel: loopStep });
            compileBlock(bodyCode);
            loopStack.pop();

            outputLines.push(`${loopStep}:`);
            if (stepPart) {
              compileStatement(stepPart + ';');
            }
            outputLines.push(`goto ${loopStart}`);
            outputLines.push(`${loopEnd}:`);
            text = remaining;
            continue;
          }

          // 3. if (cond) { body } else { body }
          const ifMatch = text.match(/^if\s*\(([^)]+)\)/);
          if (ifMatch) {
            const cond = ifMatch[1].trim();
            const afterHeader = text.substring(ifMatch[0].length).trim();
            const elseLabel = getLabel('ELSE');
            const endIfLabel = getLabel('END_IF');

            let thenCode = '';
            let remaining = '';

            if (afterHeader.startsWith('{')) {
              const bodyRange = findMatchingBrace(afterHeader, 0);
              thenCode = bodyRange.content;
              remaining = bodyRange.after.trim();
            } else {
              const semiIdx = afterHeader.indexOf(';');
              if (semiIdx !== -1) {
                thenCode = afterHeader.substring(0, semiIdx + 1);
                remaining = afterHeader.substring(semiIdx + 1).trim();
              } else {
                thenCode = afterHeader;
                remaining = '';
              }
            }

            let elseCode = '';
            let hasElse = false;
            if (remaining.startsWith('else')) {
              hasElse = true;
              let afterElse = remaining.substring(4).trim();
              if (afterElse.startsWith('{')) {
                const elseRange = findMatchingBrace(afterElse, 0);
                elseCode = elseRange.content;
                remaining = elseRange.after;
              } else {
                const semiIdx = afterElse.indexOf(';');
                if (semiIdx !== -1) {
                  elseCode = afterElse.substring(0, semiIdx + 1);
                  remaining = afterElse.substring(semiIdx + 1);
                } else {
                  elseCode = afterElse;
                  remaining = '';
                }
              }
            }

            if (hasElse) {
              outputLines.push(...compileBranchCondition(cond, elseLabel, true, varMap));
              compileBlock(thenCode);
              outputLines.push(`goto ${endIfLabel}`);
              outputLines.push(`${elseLabel}:`);
              compileBlock(elseCode);
              outputLines.push(`${endIfLabel}:`);
            } else {
              outputLines.push(...compileBranchCondition(cond, endIfLabel, true, varMap));
              compileBlock(thenCode);
              outputLines.push(`${endIfLabel}:`);
            }

            text = remaining;
            continue;
          }

          // 4. Standalone statement terminated by ';'
          const semiIdx = text.indexOf(';');
          if (semiIdx !== -1) {
            const stmt = text.substring(0, semiIdx + 1).trim();
            text = text.substring(semiIdx + 1);
            compileStatement(stmt);
            continue;
          }

          // Fallback single line
          compileStatement(text);
          break;
        }
      };

      // Helper to compile a single atomic statement
      const compileStatement = (stmt: string) => {
        let clean = stmt.replace(/;$/, '').trim();
        if (!clean) return;

        // Strip inline comment
        const cIdx = clean.indexOf('//');
        if (cIdx !== -1) clean = clean.substring(0, cIdx).trim();
        if (!clean) return;

        // Break
        if (clean === 'break') {
          if (loopStack.length > 0) {
            outputLines.push(`goto ${loopStack[loopStack.length - 1].endLabel}`);
          }
          return;
        }

        // Continue
        if (clean === 'continue') {
          if (loopStack.length > 0) {
            const ctx = loopStack[loopStack.length - 1];
            outputLines.push(`goto ${ctx.stepLabel || ctx.startLabel}`);
          }
          return;
        }

        // Return
        if (clean.startsWith('return')) {
          const retExpr = clean.substring(6).trim();
          if (retExpr) {
            outputLines.push(...compileExpression(retExpr, varMap));
            outputLines.push(`ireturn`);
          } else {
            outputLines.push(`return`);
          }
          return;
        }

        // Multiple declarations: int a = 1, b = 2, c;
        if (clean.startsWith('int ') && !clean.startsWith('int[]')) {
          const rest = clean.substring(4).trim();
          const decls = splitTopLevelCommas(rest);
          for (const d of decls) {
            const eqIdx = d.indexOf('=');
            if (eqIdx !== -1) {
              const name = d.substring(0, eqIdx).trim();
              const expr = d.substring(eqIdx + 1).trim();
              let slot = varMap.get(name);
              if (slot === undefined) {
                slot = nextSlot++;
                varMap.set(name, slot);
              }
              outputLines.push(...compileExpression(expr, varMap));
              outputLines.push(`istore ${slot}           // ${name} = ...`);
            } else {
              const name = d.trim();
              let slot = varMap.get(name);
              if (slot === undefined) {
                slot = nextSlot++;
                varMap.set(name, slot);
              }
              outputLines.push(`iconst_0`);
              outputLines.push(`istore ${slot}           // ${name} = 0`);
            }
          }
          return;
        }

        // Array declaration: int[] arr = { 1, 2, 3 } or new int[size]
        if (clean.startsWith('int[] ')) {
          const rest = clean.substring(6).trim();
          const eqIdx = rest.indexOf('=');
          if (eqIdx !== -1) {
            const name = rest.substring(0, eqIdx).trim();
            const rhs = rest.substring(eqIdx + 1).trim();
            const slot = nextSlot++;
            varMap.set(name, slot);

            if (rhs.startsWith('new int[')) {
              const sizeExpr = rhs.substring(8, rhs.indexOf(']'));
              outputLines.push(...compileExpression(sizeExpr, varMap));
              outputLines.push(`newarray 10`);
              outputLines.push(`astore ${slot}           // ${name} = new int[...]`);
            } else if (rhs.startsWith('{')) {
              const items = rhs.replace(/[{}]/g, '').split(',').map((s) => s.trim()).filter(Boolean);
              outputLines.push(pushInt(items.length));
              outputLines.push(`newarray 10`);
              outputLines.push(`astore ${slot}`);
              for (let idx = 0; idx < items.length; idx++) {
                outputLines.push(`aload ${slot}`);
                outputLines.push(pushInt(idx));
                outputLines.push(...compileExpression(items[idx], varMap));
                outputLines.push(`iastore`);
              }
            }
          }
          return;
        }

        // Array store: arr[i] = val
        const arrStore = clean.match(/^(\w+)\[([^\]]+)\]\s*=\s*(.+)$/);
        if (arrStore) {
          const arrName = arrStore[1];
          const indexExpr = arrStore[2];
          const valExpr = arrStore[3].trim();
          const slot = varMap.get(arrName);
          if (slot !== undefined) {
            outputLines.push(`aload ${slot}`);
            outputLines.push(...compileExpression(indexExpr, varMap));
            outputLines.push(...compileExpression(valExpr, varMap));
            outputLines.push(`iastore            // ${arrName}[...] = ...`);
          }
          return;
        }

        // Pre/Post Increment/Decrement: i++ or ++i or i-- or --i
        const postInc = clean.match(/^(\w+)\+\+$/);
        const preInc = clean.match(/^\+\+(\w+)$/);
        if (postInc || preInc) {
          const name = (postInc || preInc)![1];
          const slot = varMap.get(name);
          if (slot !== undefined) outputLines.push(`iinc ${slot} 1`);
          return;
        }
        const postDec = clean.match(/^(\w+)--$/);
        const preDec = clean.match(/^--(\w+)$/);
        if (postDec || preDec) {
          const name = (postDec || preDec)![1];
          const slot = varMap.get(name);
          if (slot !== undefined) outputLines.push(`iinc ${slot} -1`);
          return;
        }

        // Compound assignment: x += 5, etc.
        const compoundMatch = clean.match(/^(\w+)\s*(\+=|-=|\*=|\/=|%=|&=|\|=|\^=|<<=|>>=|>>>=)\s*(.+)$/);
        if (compoundMatch) {
          const name = compoundMatch[1];
          const op = compoundMatch[2];
          const rhs = compoundMatch[3].trim();
          const slot = varMap.get(name);
          if (slot !== undefined) {
            outputLines.push(`iload ${slot}`);
            outputLines.push(...compileExpression(rhs, varMap));
            if (op === '+=') outputLines.push(`iadd`);
            else if (op === '-=') outputLines.push(`isub`);
            else if (op === '*=') outputLines.push(`imul`);
            else if (op === '/=') outputLines.push(`idiv`);
            else if (op === '%=') outputLines.push(`irem`);
            else if (op === '&=') outputLines.push(`iand`);
            else if (op === '|=') outputLines.push(`ior`);
            else if (op === '^=') outputLines.push(`ixor`);
            else if (op === '<<=') outputLines.push(`ishl`);
            else if (op === '>>=') outputLines.push(`ishr`);
            else if (op === '>>>=') outputLines.push(`iushr`);
            outputLines.push(`istore ${slot}`);
          }
          return;
        }

        // Standard assignment: x = expr
        const assignMatch = clean.match(/^(\w+)\s*=\s*(.+)$/);
        if (assignMatch) {
          const name = assignMatch[1];
          const rhs = assignMatch[2].trim();
          let slot = varMap.get(name);
          if (slot === undefined) {
            slot = nextSlot++;
            varMap.set(name, slot);
          }
          outputLines.push(...compileExpression(rhs, varMap));
          outputLines.push(`istore ${slot}           // ${name} = ...`);
          return;
        }

        // Raw opcode assembly fallback
        if (clean.endsWith(':') || /^[a-z_0-9]+/i.test(clean)) {
          outputLines.push(clean);
        }
      };

      // Compile all body statements
      compileBlock(body);

      // Ensure terminating return
      if (!outputLines.some((l) => l.trim().startsWith('ireturn') || l.trim().startsWith('return') || l.trim().startsWith('areturn'))) {
        outputLines.push(`iconst_0`);
        outputLines.push(`ireturn`);
      }

      return {
        success: true,
        assemblySource: outputLines.join('\n'),
      };
    } catch (err: any) {
      return {
        success: false,
        assemblySource: '',
        errorMessage: err.message || String(err),
      };
    }
  }

  /**
   * Compiles condition expression and emits branch to targetLabel.
   * If invert is true, branches when condition is FALSE (used for while/if guards).
   */
  private static compileBranchCondition(cond: string, targetLabel: string, invert: boolean, varMap: Map<string, number>): string[] {
    const trimmed = cond.trim();
    const ops: string[] = [];

    // Comparison operators: ==, !=, <=, >=, <, >
    const compRegex = /(==|!=|<=|>=|<|>)/;
    const match = trimmed.match(compRegex);

    if (match) {
      const op = match[1];
      const opIdx = trimmed.indexOf(op);
      const lhs = trimmed.substring(0, opIdx).trim();
      const rhs = trimmed.substring(opIdx + op.length).trim();

      ops.push(...this.compileExpression(lhs, varMap));
      ops.push(...this.compileExpression(rhs, varMap));

      // Invert mappings for exit branches
      if (invert) {
        if (op === '==') ops.push(`if_icmpne ${targetLabel}`);
        else if (op === '!=') ops.push(`if_icmpeq ${targetLabel}`);
        else if (op === '<') ops.push(`if_icmpge ${targetLabel}`);
        else if (op === '<=') ops.push(`if_icmpgt ${targetLabel}`);
        else if (op === '>') ops.push(`if_icmple ${targetLabel}`);
        else if (op === '>=') ops.push(`if_icmplt ${targetLabel}`);
      } else {
        if (op === '==') ops.push(`if_icmpeq ${targetLabel}`);
        else if (op === '!=') ops.push(`if_icmpne ${targetLabel}`);
        else if (op === '<') ops.push(`if_icmplt ${targetLabel}`);
        else if (op === '<=') ops.push(`if_icmple ${targetLabel}`);
        else if (op === '>') ops.push(`if_icmpgt ${targetLabel}`);
        else if (op === '>=') ops.push(`if_icmpge ${targetLabel}`);
      }
      return ops;
    }

    // Single boolean variable or expression
    ops.push(...this.compileExpression(trimmed, varMap));
    if (invert) {
      ops.push(`ifeq ${targetLabel}`);
    } else {
      ops.push(`ifne ${targetLabel}`);
    }
    return ops;
  }

  /**
   * Compiles arithmetic, bitwise, math, or identifier expressions into JVM stack pushes.
   */
  private static compileExpression(expr: string, varMap: Map<string, number>): string[] {
    let trimmed = expr.trim();
    if (!trimmed) return [`iconst_0`];

    // Strip outer parentheses if balanced: (a + b)
    while (trimmed.startsWith('(') && trimmed.endsWith(')')) {
      const match = findMatchingParen(trimmed, 0);
      if (match === trimmed.length - 1) {
        trimmed = trimmed.substring(1, trimmed.length - 1).trim();
      } else {
        break;
      }
    }

    // Number literal
    if (/^-?\d+$/.test(trimmed)) {
      return [pushInt(parseInt(trimmed, 10))];
    }

    // Boolean literal
    if (trimmed === 'true') return [`iconst_1`];
    if (trimmed === 'false') return [`iconst_0`];

    // Ternary operator: (cond) ? exprA : exprB
    const ternaryIdx = findTopLevelChar(trimmed, '?');
    if (ternaryIdx !== -1) {
      const cond = trimmed.substring(0, ternaryIdx).trim();
      const rest = trimmed.substring(ternaryIdx + 1);
      const colonIdx = findTopLevelChar(rest, ':');
      if (colonIdx !== -1) {
        const trueExpr = rest.substring(0, colonIdx).trim();
        const falseExpr = rest.substring(colonIdx + 1).trim();
        const elseLbl = `L_TERN_ELSE_${Math.floor(Math.random() * 100000)}`;
        const endLbl = `L_TERN_END_${Math.floor(Math.random() * 100000)}`;

        const ops: string[] = [];
        ops.push(...this.compileBranchCondition(cond, elseLbl, true, varMap));
        ops.push(...this.compileExpression(trueExpr, varMap));
        ops.push(`goto ${endLbl}`);
        ops.push(`${elseLbl}:`);
        ops.push(...this.compileExpression(falseExpr, varMap));
        ops.push(`${endLbl}:`);
        return ops;
      }
    }

    // Math.max(a, b) and Math.min(a, b)
    const mathMatch = trimmed.match(/^Math\.(max|min|abs)\((.+)\)$/);
    if (mathMatch) {
      const fn = mathMatch[1];
      const argsStr = mathMatch[2];
      const args = splitTopLevelCommas(argsStr);
      if (fn === 'max' && args.length === 2) {
        return this.compileExpression(`(${args[0]} > ${args[1]}) ? ${args[0]} : ${args[1]}`, varMap);
      }
      if (fn === 'min' && args.length === 2) {
        return this.compileExpression(`(${args[0]} < ${args[1]}) ? ${args[0]} : ${args[1]}`, varMap);
      }
      if (fn === 'abs' && args.length === 1) {
        return this.compileExpression(`(${args[0]} < 0) ? -${args[0]} : ${args[0]}`, varMap);
      }
    }

    // Array length: arr.length
    if (trimmed.endsWith('.length')) {
      const arrName = trimmed.replace('.length', '').trim();
      const slot = varMap.get(arrName);
      if (slot !== undefined) {
        return [`aload ${slot}`, `arraylength`];
      }
    }

    // Array read: arr[index]
    const arrRead = trimmed.match(/^(\w+)\[([^\]]+)\]$/);
    if (arrRead) {
      const arrName = arrRead[1];
      const indexExpr = arrRead[2];
      const slot = varMap.get(arrName);
      if (slot !== undefined) {
        return [`aload ${slot}`, ...this.compileExpression(indexExpr, varMap), `iaload`];
      }
    }

    // Single variable: x
    if (varMap.has(trimmed)) {
      const slot = varMap.get(trimmed)!;
      return [`iload ${slot}`];
    }

    // Binary operations (parsed by operator precedence)
    const precedence = [
      ['||'],
      ['&&'],
      ['|'],
      ['^'],
      ['&'],
      ['==', '!='],
      ['<', '<=', '>', '>='],
      ['<<', '>>>', '>>'],
      ['+', '-'],
      ['*', '/', '%'],
    ];

    for (const opGroup of precedence) {
      for (const op of opGroup) {
        const opIdx = findTopLevelOperator(trimmed, op);
        if (opIdx !== -1) {
          const lhs = trimmed.substring(0, opIdx).trim();
          const rhs = trimmed.substring(opIdx + op.length).trim();
          const ops: string[] = [];
          ops.push(...this.compileExpression(lhs, varMap));
          ops.push(...this.compileExpression(rhs, varMap));

          if (op === '+') ops.push('iadd');
          else if (op === '-') ops.push('isub');
          else if (op === '*') ops.push('imul');
          else if (op === '/') ops.push('idiv');
          else if (op === '%') ops.push('irem');
          else if (op === '&') ops.push('iand');
          else if (op === '|') ops.push('ior');
          else if (op === '^') ops.push('ixor');
          else if (op === '<<') ops.push('ishl');
          else if (op === '>>') ops.push('ishr');
          else if (op === '>>>') ops.push('iushr');
          return ops;
        }
      }
    }

    return [`iconst_0`];
  }
}

/**
 * Emits bytecode instruction for integer constant.
 */
function pushInt(val: number): string {
  if (val >= 0 && val <= 5) return `iconst_${val}`;
  if (val === -1) return `iconst_m1`;
  if (val >= -128 && val <= 127) return `bipush ${val}`;
  return `sipush ${val}`;
}

/**
 * Finds matching closing brace '{' -> '}'.
 */
function findMatchingBrace(text: string, startIndex: number): { content: string; after: string } {
  let depth = 0;
  let contentStart = -1;

  for (let i = startIndex; i < text.length; i++) {
    if (text[i] === '{') {
      if (depth === 0) contentStart = i + 1;
      depth++;
    } else if (text[i] === '}') {
      depth--;
      if (depth === 0) {
        return {
          content: text.substring(contentStart, i),
          after: text.substring(i + 1),
        };
      }
    }
  }

  return {
    content: text.substring(contentStart !== -1 ? contentStart : 0),
    after: '',
  };
}

/**
 * Finds matching closing parenthesis '(' -> ')'.
 */
function findMatchingParen(text: string, startIndex: number): number {
  let depth = 0;
  for (let i = startIndex; i < text.length; i++) {
    if (text[i] === '(') depth++;
    else if (text[i] === ')') {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

/**
 * Finds top-level character not inside parentheses or brackets.
 */
function findTopLevelChar(text: string, targetChar: string): number {
  let parenDepth = 0;
  let bracketDepth = 0;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '(') parenDepth++;
    else if (ch === ')') parenDepth--;
    else if (ch === '[') bracketDepth++;
    else if (ch === ']') bracketDepth--;
    else if (ch === targetChar && parenDepth === 0 && bracketDepth === 0) {
      return i;
    }
  }
  return -1;
}

/**
 * Finds top-level multi-character operator not inside parentheses or brackets.
 */
function findTopLevelOperator(text: string, op: string): number {
  let parenDepth = 0;
  let bracketDepth = 0;

  for (let i = 0; i <= text.length - op.length; i++) {
    const ch = text[i];
    if (ch === '(') parenDepth++;
    else if (ch === ')') parenDepth--;
    else if (ch === '[') bracketDepth++;
    else if (ch === ']') bracketDepth--;
    else if (parenDepth === 0 && bracketDepth === 0 && text.substring(i, i + op.length) === op) {
      // Avoid matching sub-tokens like '-' inside '--' or '<' inside '<<'
      const prev = i > 0 ? text[i - 1] : '';
      const next = i + op.length < text.length ? text[i + op.length] : '';
      if (op === '-' && (prev === '-' || next === '-')) continue;
      if (op === '+' && (prev === '+' || next === '+')) continue;
      if (op === '<' && (prev === '<' || next === '<' || next === '=')) continue;
      if (op === '>' && (prev === '>' || next === '>' || next === '=')) continue;
      return i;
    }
  }
  return -1;
}

/**
 * Splits comma-separated expressions at the top level (outside parentheses and brackets).
 */
function splitTopLevelCommas(str: string): string[] {
  const parts: string[] = [];
  let current = '';
  let parenDepth = 0;
  let bracketDepth = 0;

  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    if (ch === '(') parenDepth++;
    else if (ch === ')') parenDepth--;
    else if (ch === '[') bracketDepth++;
    else if (ch === ']') bracketDepth--;
    else if (ch === ',' && parenDepth === 0 && bracketDepth === 0) {
      parts.push(current.trim());
      current = '';
      continue;
    }
    current += ch;
  }
  if (current.trim()) {
    parts.push(current.trim());
  }
  return parts;
}
